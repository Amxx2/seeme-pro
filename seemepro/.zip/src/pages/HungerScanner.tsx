import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Drumstick, Info, Radio, Share2, MessageCircle, Send, Download, Upload, FolderOpen } from 'lucide-react';
import { CinematicHungerHUD } from '../components/CinematicHungerHUD';
import { analyzeHungerWithOpenAI, type HungerResult } from '../utils/hungerAnalysisService';
import { useAppStore } from '../store/useAppStore';
import { RewardedAdModal } from '../components/RewardedAdModal';

const ACCEPTED_AUDIO = 'audio/*,.mp3,.wav,.m4a,.ogg,.webm,.aac,.flac';

const HungerScanner = () => {
    const [mode, setMode] = useState<'record' | 'upload'>('record');
    const [recording, setRecording] = useState(false);
    const [processing, setProcessing] = useState(false);
    const [result, setResult] = useState<HungerResult | null>(null);
    const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
    const [permError, setPermError] = useState(false);
    const [dragOver, setDragOver] = useState(false);
    const [uploadedFileName, setUploadedFileName] = useState<string | null>(null);
    const [audioLevel, setAudioLevel] = useState(0);

    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const chunksRef = useRef<BlobPart[]>([]);
    const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { user, consumeCredit, addCreditFromAd } = useAppStore();
    const [showAdModal, setShowAdModal] = useState(false);

    const processFile = async (file: File) => {
        if (!file.type.startsWith('audio/') && !file.name.match(/\.(mp3|wav|m4a|ogg|webm|aac|flac)$/i)) {
            alert('Please upload an audio file (mp3, wav, m4a, webm, aac, flac)');
            return;
        }

        const hasCredit = consumeCredit('hunger');
        if (!hasCredit) {
            setShowAdModal(true);
            return;
        }

        setUploadedFileName(file.name);
        setAudioBlob(file);
        setResult(null);
        setProcessing(true);
        setPermError(false);

        const audioUrl = URL.createObjectURL(file);
        const audioEl = new Audio(audioUrl);
        let trackingCtx: AudioContext | null = null;
        let animFrame: number | null = null;

        try {
            trackingCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
            const analyser = trackingCtx.createAnalyser();
            analyser.fftSize = 256;
            const source = trackingCtx.createMediaElementSource(audioEl);
            source.connect(analyser);
            analyser.connect(trackingCtx.destination);

            audioEl.play().catch(e => console.warn("Auto-play blocked", e));

            const updateLevel = () => {
                const dataArray = new Uint8Array(analyser.frequencyBinCount);
                analyser.getByteFrequencyData(dataArray);
                const avg = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
                setAudioLevel(Math.min(100, Math.round((avg / 255) * 150)));
                animFrame = requestAnimationFrame(updateLevel);
            };
            updateLevel();
        } catch (err) {
            console.warn("Could not attach audio visualization", err);
        }

        let completed = false;
        const timeoutId = setTimeout(() => {
            if (!completed) {
                setProcessing(false);
                completed = true;
                alert("انتهى وقت التحليل (30 ثانية). يرجى المحاولة مرة أخرى.");
            }
        }, 30000);

        try {
            const res = await analyzeHungerWithOpenAI(file);
            if (completed) return;
            completed = true;
            clearTimeout(timeoutId);
            setResult(res);
        } catch (error) {
            if (completed) return;
            completed = true;
            clearTimeout(timeoutId);
            console.error(error);
            alert('Analysis failed. Please try again.');
        } finally {
            if (!completed) setProcessing(false);
            audioEl.pause();
            audioEl.src = "";
            URL.revokeObjectURL(audioUrl);
            if (trackingCtx) trackingCtx.close().catch(() => { });
            if (animFrame) cancelAnimationFrame(animFrame);
            setAudioLevel(0);
        }
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) processFile(file);
    };

    const handleDrop = (e: React.DragEvent) => {
        e.preventDefault(); setDragOver(false);
        const file = e.dataTransfer.files[0];
        if (file) processFile(file);
    };

    const start = async () => {
        try {
            setPermError(false);
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

            const hasCredit = consumeCredit('hunger');
            if (!hasCredit) {
                stream.getTracks().forEach(t => t.stop());
                setShowAdModal(true);
                return;
            }

            const mr = new MediaRecorder(stream);
            mediaRecorderRef.current = mr;
            chunksRef.current = [];
            mr.ondataavailable = (e) => chunksRef.current.push(e.data);
            mr.onstop = async () => {
                const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
                setAudioBlob(blob);
                stream.getTracks().forEach(t => t.stop());
                setProcessing(true);

                const audioUrl = URL.createObjectURL(blob);
                const audioEl = new Audio(audioUrl);
                let trackingCtx: AudioContext | null = null;
                let animFrame: number | null = null;

                try {
                    trackingCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
                    const analyser = trackingCtx.createAnalyser();
                    analyser.fftSize = 256;
                    const source = trackingCtx.createMediaElementSource(audioEl);
                    source.connect(analyser);
                    analyser.connect(trackingCtx.destination);

                    audioEl.play().catch(e => console.warn("Auto-play blocked", e));

                    const updateLevel = () => {
                        const dataArray = new Uint8Array(analyser.frequencyBinCount);
                        analyser.getByteFrequencyData(dataArray);
                        const avg = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
                        setAudioLevel(Math.min(100, Math.round((avg / 255) * 150)));
                        animFrame = requestAnimationFrame(updateLevel);
                    };
                    updateLevel();
                } catch (err) {
                    console.warn("Could not attach audio visualization", err);
                }

                let completed = false;
                const timeoutId = setTimeout(() => {
                    if (!completed) {
                        setProcessing(false);
                        completed = true;
                        alert("انتهى وقت التحليل (30 ثانية). يرجى المحاولة مرة أخرى.");
                    }
                }, 30000);

                try {
                    const res = await analyzeHungerWithOpenAI(blob);
                    if (completed) return;
                    completed = true;
                    clearTimeout(timeoutId);
                    setResult(res);
                } catch (error) {
                    if (completed) return;
                    completed = true;
                    clearTimeout(timeoutId);
                    console.error(error);
                    alert('Analysis failed. Please try again.');
                } finally {
                    if (!completed) setProcessing(false);
                    audioEl.pause();
                    audioEl.src = "";
                    URL.revokeObjectURL(audioUrl);
                    if (trackingCtx) trackingCtx.close().catch(() => { });
                    if (animFrame) cancelAnimationFrame(animFrame);
                    setAudioLevel(0);
                }
            };
            mr.start(); setRecording(true); setResult(null);
        } catch { setPermError(true); }
    };

    const stop = () => {
        if (timerRef.current) clearInterval(timerRef.current);
        mediaRecorderRef.current?.stop(); setRecording(false);
    };

    const shareResult = async (platform: 'whatsapp' | 'telegram' | 'native' | 'download') => {
        if (!result) return;
        const text = `🍗 SEEMEPRO Hunger Scanner\n\nHunger Level: ${result.level} ${result.emoji}\nScore: ${result.score}/100\n\n${result.verdict}\n\nScan your friends at SEEMEPRO 👁️`;
        if (platform === 'whatsapp') window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
        else if (platform === 'telegram') window.open(`https://t.me/share/url?url=${encodeURIComponent('https://seemepro.app')}&text=${encodeURIComponent(text)}`, '_blank');
        else if (platform === 'native' && navigator.share) {
            try {
                const files = audioBlob ? [new File([audioBlob], uploadedFileName ?? 'hunger-scan.webm', { type: audioBlob.type })] : [];
                await navigator.share({ title: 'SEEMEPRO Hunger Scan', text, files: files.length ? files : undefined });
            } catch { /* cancelled */ }
        } else if (platform === 'download' && audioBlob) {
            const a = document.createElement('a');
            a.href = URL.createObjectURL(audioBlob);
            a.download = uploadedFileName ?? 'seemepro-hunger-scan.webm'; a.click();
        }
    };

    const levelColor = (l: string) =>
        ({ STARVING: 'text-red-400', HUNGRY: 'text-orange-400', PECKISH: 'text-yellow-400', 'FULLY FED': 'text-green-400' }[l] ?? 'text-gray-400');

    const reset = () => { setResult(null); setAudioBlob(null); setUploadedFileName(null); };

    return (
        <div className="max-w-2xl mx-auto">
            {/* Header */}
            <div className="mb-8">
                <div className="flex items-center gap-4 mb-4">
                    <div className="w-14 h-14 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center shadow-[0_0_20px_rgba(249,115,22,0.15)]">
                        <Drumstick className="w-7 h-7 text-orange-400" />
                    </div>
                    <div>
                        <div className="text-xs text-orange-400 font-black uppercase tracking-[0.3em] mb-1 flex items-center gap-2">
                            😄 Fun Feature
                            <span className="bg-orange-500/20 text-orange-400 px-2 py-0.5 rounded-full text-[10px] tracking-widest border border-orange-500/30">
                                🍔 {user.credits.hunger} Credits
                            </span>
                        </div>
                        <h1 className="text-3xl font-black text-white uppercase tracking-tighter">Hunger Scanner</h1>
                    </div>
                </div>
                <p className="text-gray-400 text-sm leading-relaxed">Record or upload your friend's voice. AI detects <strong className="text-white">vocal irritability, energy drops, and dry-mouth patterns</strong> to tell if they are hungry or fasting.</p>
                {permError && <div className="mt-3 bg-red-500/10 border border-red-500/30 rounded-2xl p-4 text-red-400 text-sm font-bold">Microphone access denied. Allow mic permissions in browser settings.</div>}
                <div className="mt-4 bg-blue-500/5 border border-blue-500/20 rounded-2xl p-3 flex items-start gap-3">
                    <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-gray-400">Fun entertainment only. Based on real vocal stress science — do not skip meals based on this!</p>
                </div>
            </div>

            {/* Mode tabs */}
            <div className="flex gap-2 mb-5 bg-white/3 p-1 rounded-2xl border border-white/8">
                {(['record', 'upload'] as const).map(m => (
                    <button key={m} onClick={() => setMode(m)}
                        className={`flex-1 py-2.5 rounded-xl text-sm font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2
                            ${mode === m ? 'bg-white text-black shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}>
                        {m === 'record' ? <><Radio className="w-4 h-4" />Record</> : <><Upload className="w-4 h-4" />Upload File</>}
                    </button>
                ))}
            </div>

            {/* Main HUD */}
            {(recording || processing || result) ? (
                <div className="w-full mb-5 relative">
                    {processing && !result && (
                        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm rounded-3xl border border-white/10 m-4 sm:m-0">
                            <div className="w-16 h-16 border-4 border-[#ff4e00] border-t-transparent rounded-full animate-spin mb-4"></div>
                            <p className="text-[#ff4e00] font-bold tracking-widest animate-pulse">جاري تحليل النوايا...</p>
                        </div>
                    )}
                    <CinematicHungerHUD
                        isRecording={recording}
                        isAnalyzing={processing}
                        onStop={stop}
                        hasData={!!result}
                        audioLevel={audioLevel}
                        onShowReport={() => {
                            // Result display handles this below
                            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
                        }}
                    />
                </div>
            ) : (
                <div className="bg-[#0a0c16] border border-white/8 rounded-3xl p-8 mb-5 text-center">
                    <p className="text-gray-400 mb-6">Press Start Recording or Upload an audio file to begin.</p>

                    {mode === 'record' ? (
                        <button onClick={start} className="w-full py-4 rounded-2xl bg-orange-500 text-white font-black uppercase tracking-widest text-sm flex items-center justify-center gap-3 hover:bg-orange-600 active:scale-95 transition-all shadow-[0_0_20px_rgba(249,115,22,0.3)]">
                            <Radio className="w-5 h-5" />Start Recording
                        </button>
                    ) : (
                        <div
                            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                            onDragLeave={() => setDragOver(false)}
                            onDrop={handleDrop}
                            className={`bg-[#0a0c16] border-2 border-dashed rounded-3xl p-10 text-center transition-all cursor-pointer
                                  ${dragOver ? 'border-orange-500/60 bg-orange-500/5' : 'border-white/10 hover:border-orange-500/30 hover:bg-orange-500/3'}`}
                            onClick={() => fileInputRef.current?.click()}
                        >
                            <input ref={fileInputRef} type="file" accept={ACCEPTED_AUDIO} onChange={handleFileChange} className="hidden" />
                            <FolderOpen className={`w-10 h-10 mx-auto mb-4 ${dragOver ? 'text-orange-400' : 'text-gray-600'}`} />
                            <p className="text-white font-black uppercase tracking-wide text-sm mb-1">
                                {uploadedFileName ?? 'Drop audio file or click to browse'}
                            </p>
                            <p className="text-gray-600 text-xs">mp3 · wav · m4a · webm · aac · flac · ogg</p>
                        </div>
                    )}
                </div>
            )}

            {/* Results */}
            <AnimatePresence>
                {result && !processing && (
                    <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
                        className="bg-[#0a0c16] border border-white/8 rounded-3xl p-8">
                        <div className="text-center mb-8">
                            <div className="text-6xl mb-3">{result.emoji}</div>
                            <div className={`text-5xl font-black ${levelColor(result.level)}`}>{result.level}</div>
                            <div className="text-gray-500 text-sm mt-1">Hunger Score: <span className={`font-black ${levelColor(result.level)}`}>{result.score}/100</span></div>
                        </div>
                        <div className="space-y-4 mb-8">
                            {result.traits.map(t => (
                                <div key={t.key}>
                                    <div className="flex justify-between text-xs mb-1.5">
                                        <span className="text-gray-400 font-bold">{t.label}</span>
                                        <span className="font-black text-orange-400">{t.value}%</span>
                                    </div>
                                    <div className="w-full bg-white/5 rounded-full h-1.5">
                                        <motion.div className="h-1.5 rounded-full bg-gradient-to-r from-orange-500 to-yellow-400"
                                            initial={{ width: 0 }} animate={{ width: `${t.value}%` }} transition={{ duration: 0.8, delay: 0.2 }} />
                                    </div>
                                </div>
                            ))}
                        </div>
                        <div className="bg-white/3 border border-white/8 rounded-2xl p-5 mb-6">
                            <p className="text-gray-300 text-sm leading-relaxed">{result.verdict}</p>
                        </div>
                        {/* Share */}
                        <p className="text-xs text-gray-600 uppercase tracking-widest font-black text-center mb-3">Share & Save</p>
                        <div className="grid grid-cols-2 gap-3 mb-4">
                            <button onClick={() => shareResult('whatsapp')} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-green-600/20 border border-green-600/30 text-green-400 hover:bg-green-600/30 transition-colors text-sm font-bold"><MessageCircle className="w-4 h-4" />WhatsApp</button>
                            <button onClick={() => shareResult('telegram')} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-blue-500/20 border border-blue-500/30 text-blue-400 hover:bg-blue-500/30 transition-colors text-sm font-bold"><Send className="w-4 h-4" />Telegram</button>
                            <button onClick={() => shareResult('native')} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 transition-colors text-sm font-bold"><Share2 className="w-4 h-4" />Share</button>
                            <button onClick={() => shareResult('download')} disabled={!audioBlob} className="flex items-center justify-center gap-2 py-3 rounded-xl bg-white/5 border border-white/10 text-gray-300 hover:bg-white/10 transition-colors text-sm font-bold disabled:opacity-40"><Download className="w-4 h-4" />Save Audio</button>
                        </div>
                        <button onClick={reset} className="w-full py-3 rounded-xl border border-white/10 text-gray-400 hover:text-white text-sm font-bold uppercase tracking-wider transition-colors">Scan Again</button>
                    </motion.div>
                )}
            </AnimatePresence>

            <RewardedAdModal
                isOpen={showAdModal}
                feature="hunger"
                onClose={() => setShowAdModal(false)}
                onComplete={() => {
                    addCreditFromAd('hunger');
                    setShowAdModal(false);
                }}
            />
        </div>
    );
};

export default HungerScanner;
